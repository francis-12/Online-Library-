/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.*;

/**
 *
 * @author princecalvinsagatwa
 */
@Entity
@Table (name = "client")
public class Client {
    @Id
    @Column(name = "reg_id",length = 5)
    private String reg_id;
    @Column(name = "first_name")
    private String first_name;
    @Column(name = "last_name")
    private String last_name;
    @Column(name = "phone_number")
    private String phone_number;
    private String email;
//    @Enumerated(EnumType.STRING)
    @Column(name = "client_category")
//    private ClientCategoryEnum client_category;
    private String client_category;
//    @Lob
    private byte[] photo;
    @Column(name = "photo_link")
    private String photoLink;

    public Client() {
    }

    public Client(String reg_id, String first_name, String last_name, String phone_number, String email, String client_category, byte[] photo, String photoLink) {
        this.reg_id = reg_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.phone_number = phone_number;
        this.email = email;
        this.client_category = client_category;
        this.photo = photo;
        this.photoLink = photoLink;
    }

    public String getReg_id() {
        return reg_id;
    }

    public void setReg_id(String reg_id) {
        this.reg_id = reg_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClient_category() {
        return client_category;
    }

    public void setClient_category(String client_category) {
        this.client_category = client_category;
    }

    public byte[] getPhoto() {
        return photo;
    }

    public void setPhoto(byte[] photo) {
        this.photo = photo;
    }

    public String getPhotoLink() {
        return photoLink;
    }

    public void setPhotoLink(String photoLink) {
        this.photoLink = photoLink;
    }

    
    
}
