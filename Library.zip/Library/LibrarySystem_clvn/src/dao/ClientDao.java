/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.*;
import javax.swing.JOptionPane;
import model.Client;
import org.hibernate.*;

/**
 *
 * @author princecalvinsagatwa
 */
public class ClientDao {
    public void saveClient(Client client){
        //Create session
        Session ss=null;
        Transaction tr=null;
        try
        {
            ss=HibernateUtil.getSessionFactory().openSession();
            tr=ss.beginTransaction();
            ss.save(client);
            tr.commit();
            JOptionPane.showMessageDialog(null, "New client has been saved successfully!", "Saving a client", JOptionPane.INFORMATION_MESSAGE);
        }catch(HibernateException ex){
            ex.printStackTrace();
//            if(tr!=null){
//                tr.rollback();
//            }
//            JOptionPane.showMessageDialog(null, ex.getMessage());
        }finally{
            if(ss!=null){
                ss.close();
            }
        }
    }
    
    public List<Client> retrieveClients(){
        List<Client> clients = new ArrayList<>();
        Session ss=null;
        try{
            ss=HibernateUtil.getSessionFactory().openSession();
            clients = ss.createQuery("FROM Client").list();
        }catch(HibernateException ex){
            JOptionPane.showMessageDialog(null, ex);
        }finally{
            if(ss!=null){
                ss.close();
            }
        }        
        return clients;
    }
}
