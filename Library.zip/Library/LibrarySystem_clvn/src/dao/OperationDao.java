/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.swing.JOptionPane;
import model.Book;
import model.BookTransaction;
import model.Client;
import org.hibernate.*;

/**
 *
 * @author princecalvinsagatwa
 */
public class OperationDao {
    public void saveOperation(BookTransaction transaction){
        //Create session
        Session ss=null;
        Transaction tr=null;
        try
        {
            ss=HibernateUtil.getSessionFactory().openSession();
            tr=ss.beginTransaction();
            ss.save(transaction);
            tr.commit();
             JOptionPane.showMessageDialog(null, "New transaction saved successfully!", "Saving transaction", JOptionPane.INFORMATION_MESSAGE);
        }catch(HibernateException ex){
            if(tr!=null){
                tr.rollback();
            }
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }finally{
            if(ss!=null){
                ss.close();
            }
        }
    }
}
