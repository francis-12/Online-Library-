/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.*;
import javax.swing.JOptionPane;
import model.Book;
import model.BookCategory;
import org.hibernate.*;

/**
 *
 * @author princecalvinsagatwa
 */
public class BookDao {
    private Session session = null;
   private Transaction tx = null;
//   , String categoryCode
   public void saveBook(Book book){
       try{
           session = HibernateUtil.getSessionFactory().openSession();
           tx = session.beginTransaction();
           
           session.save(book);
           tx.commit();
           JOptionPane.showMessageDialog(null, "New book has been saved successfully!", "Saving a book", JOptionPane.INFORMATION_MESSAGE);
       }catch(HibernateException ex){
           if(tx!=null){
               tx.rollback();
           }
           JOptionPane.showMessageDialog(null, ex.getMessage());
       }finally{
           if(session!=null){
               session.close();
           }
       }
   }
   
   public void saveBookCategory(BookCategory bookcategory){
       try{
           session = HibernateUtil.getSessionFactory().openSession();
           tx = session.beginTransaction();
           
           session.save(bookcategory);
           tx.commit();
           JOptionPane.showMessageDialog(null, "Book category has been saved successfully!", "Saving book category ", JOptionPane.INFORMATION_MESSAGE);
       }catch(HibernateException ex){
           if(tx!=null){
               tx.rollback();
           }
           JOptionPane.showMessageDialog(null, ex.getMessage());
       }finally{
           if(session!=null){
               session.close();
           }
       }
   }
   
   public List<Book> retrieveBook(){
        List<Book> clients = new ArrayList<>();
        Session ss=null;
        try{
            ss=HibernateUtil.getSessionFactory().openSession();
            clients = ss.createQuery("FROM Book").list();
        }catch(HibernateException ex){
            JOptionPane.showMessageDialog(null, ex);
        }finally{
            if(ss!=null){
                ss.close();
            }
        }        
        return clients;
    }
   
   public List<BookCategory> retrieveBookCategory(){
        List<BookCategory> clients = new ArrayList<>();
        Session ss=null;
        try{
            ss=HibernateUtil.getSessionFactory().openSession();
            clients = ss.createQuery("FROM BookCategory").list();
        }catch(HibernateException ex){
            JOptionPane.showMessageDialog(null, ex);
        }finally{
            if(ss!=null){
                ss.close();
            }
        }        
        return clients;
    }
}
