/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.client;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author AmTheNetwork
 */
public class dao {
     public void saveClient(client client){
        //Create session
        Session ss=null;
        Transaction tr=null;
        try
        {
            ss=HibernateUtil.getSessionFactory().openSession();
            tr=ss.beginTransaction();
            ss.save(client);
            tr.commit();
            JOptionPane.showMessageDialog(null, "New client has been saved successfully!", "Saving a client", JOptionPane.INFORMATION_MESSAGE);
        }catch(HibernateException ex){
            ex.printStackTrace();
        }finally{
            if(ss!=null){
                ss.close();
            }
        }
    }
      public List<client> Read(){
       List<client> list = new ArrayList<>();
       Session ss = null;
       try{
           ss=HibernateUtil.getSessionFactory().openSession();
           list = ss.createQuery("from client").list();
           
       }catch(HibernateException ex)
       {
           ex.printStackTrace();
       }
      return list;
      }
}

