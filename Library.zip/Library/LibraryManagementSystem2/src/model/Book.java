/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import javax.persistence.*;

/**
 *
 * @author princecalvinsagatwa
 */
@Entity
@Table(name = "book")
public class Book {
    @Id
    @Column(name = "book_id",length = 5)
    private String book_id;
    private String title;
    private String author;
    @Column(name = "publishing_house")
    private String publishing_house;
    @Temporal(TemporalType.DATE)
    @Column(name = "publication_date")
    private Date publication_date;
    private Integer pages;
    private String available;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "category")
    private BookCategory category;

    public Book() {
    }

    public Book(String book_id, String title, String author, String publishing_house, Date publication_date, Integer pages, String available, BookCategory category) {
        this.book_id = book_id;
        this.title = title;
        this.author = author;
        this.publishing_house = publishing_house;
        this.publication_date = publication_date;
        this.pages = pages;
        this.available = available;
        this.category = category;
    }
    

    public String getBook_id() {
        return book_id;
    }

    public void setBook_id(String book_id) {
        this.book_id = book_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublishing_house() {
        return publishing_house;
    }

    public void setPublishing_house(String publishing_house) {
        this.publishing_house = publishing_house;
    }

    public Date getPublication_date() {
        return publication_date;
    }

    public void setPublication_date(Date publication_ate) {
        this.publication_date = publication_ate;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    public String isAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public BookCategory getCategory() {
        return category;
    }

    public void setCategory(BookCategory category) {
        this.category = category;
    }
}
