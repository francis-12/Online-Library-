/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import javax.persistence.*;

/**
 *
 * @author princecalvinsagatwa
 */
@Entity
@Table(name = "book_transaction")
public class BookTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String Id;
    @Temporal(TemporalType.DATE)
    @Column(name = "transaction_date")
    private Date transaction_date;
    @Temporal(TemporalType.DATE)
    @Column(name = "return_date")
    private Date return_date;
    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type")
    private TransactionTypeEnum type;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "client")
    private client client;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "book")
    private Book Book;

    public BookTransaction() {
    }

    public BookTransaction(String Id, Date transaction_date, Date return_date, TransactionTypeEnum type, client client, Book Book) {
        this.Id = Id;
        this.transaction_date = transaction_date;
        this.return_date = return_date;
        this.type = type;
        this.client = client;
        this.Book = Book;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public Date getTransaction_date() {
        return transaction_date;
    }

    public void setTransaction_date(Date transaction_date) {
        this.transaction_date = transaction_date;
    }

    public Date getReturn_date() {
        return return_date;
    }

    public void setReturn_date(Date return_date) {
        this.return_date = return_date;
    }

    public TransactionTypeEnum getType() {
        return type;
    }

    public void setType(TransactionTypeEnum type) {
        this.type = type;
    }

    public client getClient() {
        return client;
    }

    public void setClient(client client) {
        this.client = client;
    }

    public Book getBook() {
        return Book;
    }

    public void setBook(Book Book) {
        this.Book = Book;
    }

    

    
}
